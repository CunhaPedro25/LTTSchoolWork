# LTTSchoolWork
LinusTechTips website that im doing for school
